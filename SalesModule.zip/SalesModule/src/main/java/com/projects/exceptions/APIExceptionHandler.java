package com.projects.exceptions;

import java.time.LocalDateTime;

import org.hibernate.PropertyValueException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class APIExceptionHandler {

	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ApiException> handleException(ProductNotFoundException exception, HttpServletRequest request){
		ApiException apiException= new ApiException(request.getRequestURI(),exception.getMessage(),exception.getClass().toString() ,HttpStatus.BAD_REQUEST ,HttpStatus.BAD_REQUEST.value(),LocalDateTime.now());
		return new ResponseEntity<>(apiException,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(PropertyValueException.class)
	public ResponseEntity<ApiException> handleException(PropertyValueException exception, HttpServletRequest request){
		ApiException apiException= new ApiException(request.getRequestURI(),exception.getMessage(),exception.getClass().toString() ,HttpStatus.BAD_REQUEST ,HttpStatus.BAD_REQUEST.value(),LocalDateTime.now());
		return new ResponseEntity<>(apiException,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(InsufficientQuantityException.class)
	public ResponseEntity<ApiException> handleException(InsufficientQuantityException exception, HttpServletRequest request){
		ApiException apiException= new ApiException(request.getRequestURI(),exception.getMessage(),exception.getClass().toString() ,HttpStatus.NOT_MODIFIED ,HttpStatus.NOT_MODIFIED.value(),LocalDateTime.now());
		return new ResponseEntity<>(apiException,HttpStatus.BAD_REQUEST);
	}
	
}
