package com.projects.exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ApiException {
	
	private String path;
	private String message;
	private String throwable;
	private HttpStatus status;
	private int statuscode;
	private LocalDateTime dateTime;
}
