package com.projects.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projects.model.Sale;

public interface SaleRepository extends JpaRepository<Sale, Integer>{

}
