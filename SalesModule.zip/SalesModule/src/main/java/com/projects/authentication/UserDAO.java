package com.projects.authentication;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDAO {
	 private Integer id;
	 private String name;
	 private String designation;
	 private String unit;
	 private String email;
	 private Role role;
	 private boolean active;
	 private boolean locked;
	 private Date sdate;
	 private Date edate;
}
