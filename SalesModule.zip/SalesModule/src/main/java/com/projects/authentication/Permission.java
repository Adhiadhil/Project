package com.projects.authentication;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Permission {

	REGISTRATION_READ("registration:read"),
	REGISTRATION_CREATE("registration:create"),
	REGISTRATION_UPDATE("registration:update"),
	REGISTRATION_DELETE("registration:delete"),
	
	SOCIETY_READ("society:read"),
	SOCIETY_CREATE("society:create"),
	SOCIETY_UPDATE("society:update"),
	SOCIETY_DELETE("society:delete"),
	
	PARTICIPANT_READ("participant:read"),
	PARTICIPANT_CREATE("participant:create"),
	PARTICIPANT_UPDATE("participant:update"),
	PARTICIPANT_DELETE("participant:delete")
	;
	
	@Getter
	private final String permission;
}
