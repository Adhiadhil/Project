package com.projects.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.projects.dto.APIRequest;
import com.projects.dto.APIResponse;
import com.projects.dto.SaleRequestDTO;
import com.projects.exceptions.InsufficientQuantityException;
import com.projects.exceptions.ProductNotFoundException;
import com.projects.model.Product;
import com.projects.model.Sale;
import com.projects.service.ProductService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/product")
@RequiredArgsConstructor
public class ProductController {

	private final ProductService productService;
	
	@GetMapping
	public ResponseEntity<Page<Product>> getAllProducts(@RequestBody APIRequest apiRequest ){
		return new ResponseEntity<Page<Product>>(productService.getAllProducts(apiRequest), HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		return new ResponseEntity<Product>(productService.addProduct(product), HttpStatus.CREATED);
		
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable("id") int id) throws ProductNotFoundException{
		return new ResponseEntity<Product>(productService.getProductById(id), HttpStatus.OK);
	}
	
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product, @RequestParam("id") int id){
		return new ResponseEntity<Product>(productService.updateProduct(id, product), HttpStatus.OK);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Product> deleteProduct (@PathVariable("id") int id){
		productService.deleteProduct(id);
		return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
	}
	
	@PostMapping("/sales")
	public ResponseEntity<Sale> generateSales(@RequestBody SaleRequestDTO sale) throws ProductNotFoundException, InsufficientQuantityException{
		return new ResponseEntity<Sale>(productService.generateSale(sale), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/revenue")
	public ResponseEntity<APIResponse> getTotalRevenue(){
		return new ResponseEntity<APIResponse>(productService.getTotalRevenue(), HttpStatus.OK);
		
	}
	
	@GetMapping("/revenue/{id}")
	public ResponseEntity<APIResponse> getRevenueByProduct(@PathVariable("id") int id) throws ProductNotFoundException{
		return new ResponseEntity<APIResponse>(productService.getRevenueByProduct(id), HttpStatus.OK);
		
	}
	
}
