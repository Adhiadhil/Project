package com.projects.controller;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.projects.auth.AuthenticationResponse;
import com.projects.auth.AuthenticationService;
import com.projects.auth.RegisterRequest;
import com.projects.authentication.User;
import com.projects.authentication.UserDAO;
import com.projects.authentication.UserService;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("api/v1/user")
@RequiredArgsConstructor
@Slf4j
public class UserController {
	
	private final UserService service;
	private final AuthenticationService service2;

	@GetMapping("/userdetails")
	public ResponseEntity<UserDAO> userDetails(@RequestParam("mail") String userMail){
		log.info("User details fetching...");
		User user= service.getUserBymail(userMail);
		UserDAO dao = UserDAO.builder()
				.id(user.getId())
				.email(userMail)
				.name(user.getName())
				.role(user.getRole())
				.active(user.isActive())
				.locked(user.isLocked())
				.sdate(user.getStartDate())
				.edate(user.getEndDate())
				.build();
		return new ResponseEntity<UserDAO>(dao,HttpStatus.OK);
	}
	
	
	  @PostMapping("/register")
	  public ResponseEntity<AuthenticationResponse> register(
	      @RequestBody RegisterRequest request
	  ) {
	    return ResponseEntity.ok(service2.register(request));
	  }
}

@Data
class requestBody{
	private int userId;
	private boolean active;
	private boolean locked;
	private Date sdate;
	private Date edate;
}
	
	



