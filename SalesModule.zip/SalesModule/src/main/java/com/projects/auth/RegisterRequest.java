package com.projects.auth;

import java.util.Date;

import com.projects.authentication.Role;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {

  private String name;
  private boolean active;
  private boolean locked;
  private String email;
  private String password;
  private Date startDate;
  private Date endDate;
  private Role role; 
}
