package com.projects.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.projects.dto.APIRequest;
import com.projects.dto.APIResponse;
import com.projects.dto.SaleRequestDTO;
import com.projects.exceptions.InsufficientQuantityException;
import com.projects.exceptions.ProductNotFoundException;
import com.projects.model.Product;
import com.projects.model.Sale;

public interface ProductService {

	Page<Product> getAllProducts(APIRequest apiRequest);
	Product getProductById(int id) throws ProductNotFoundException;
	Product addProduct (Product request);
	Product updateProduct(int id, Product product);
	void deleteProduct(int id);
	Sale generateSale(SaleRequestDTO sale) throws ProductNotFoundException, InsufficientQuantityException;
	APIResponse getTotalRevenue();
	APIResponse getRevenueByProduct(int productId) throws ProductNotFoundException;
}
