package com.projects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
